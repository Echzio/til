module.exports = {
    runner:               'jest-runner-eslint',
    displayName:          'lint:javascript',
    rootDir:              '../../',
    moduleFileExtensions: [ 'js' ],
    testMatch:            [ '<rootDir>/source/**/*.js' ],
};
