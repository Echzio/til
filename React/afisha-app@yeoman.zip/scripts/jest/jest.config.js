module.exports = {
    rootDir:  '../../',
    projects: [
        '<rootDir>/scripts/jest/jest.test.config.js',
        '<rootDir>/scripts/jest/jest.eslint.config.js',
        '<rootDir>/scripts/jest/jest.stylelint.config.js',
    ],
};
