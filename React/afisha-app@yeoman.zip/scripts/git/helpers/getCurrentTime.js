// Core
import moment from 'moment';

export const getCurrentTime = () => moment().format('HH:mm:ss');
