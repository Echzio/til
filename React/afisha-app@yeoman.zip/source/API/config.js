export class Config {
    BASE_URI = 'https://lab.lectrum.io/afisha/api';
}

export const config = new Config();
