export const fetch = jest.fn(() => Promise.resolve('fetched'));
